package org.example;

import org.example.Model.Medicamento;
import org.example.Model.Usuario;
import org.example.Service.MedicamentoService;
import org.example.Service.UsuarioService;

public class Main {

    public static void main(String[] args) {

        UsuarioService usuarioService =
                new UsuarioService();

        MedicamentoService medicamentoService =
                new MedicamentoService();

        Usuario usuario =
                new Usuario(
                        1,
                        "Genesis",
                        "genesis",
                        "1234",
                        "ADMIN"
                );

        usuarioService.agregarUsuario(usuario);

        Medicamento medicamento =
                new Medicamento(
                        1,
                        "Amoxicilina",
                        "Antibiotico",
                        50
                );

        medicamentoService.agregar(medicamento);

        System.out.println("Datos almacenados en MySQL");
    }
}