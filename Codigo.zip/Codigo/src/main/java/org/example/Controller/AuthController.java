package org.example.Controller;

import org.example.Service.UsuarioService;

public class AuthController {

    private UsuarioService service =
            new UsuarioService();

    public boolean login(
            String username,
            String password){

        return service.login(
                username,
                password);
    }
}