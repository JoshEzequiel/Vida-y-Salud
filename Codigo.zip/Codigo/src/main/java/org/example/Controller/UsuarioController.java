package org.example.Controller;



import org.example.Model.Usuario;
import org.example.Service.UsuarioService;

public class UsuarioController {

    private UsuarioService service =
            new UsuarioService();

    public void crearUsuario(
            Usuario usuario){

        service.agregarUsuario(usuario);
    }
}
