package org.example.Controller;



import org.example.Model.Medicamento;
import org.example.Service.MedicamentoService;

public class MedicamentoController {

    private MedicamentoService service =
            new MedicamentoService();

    public void crearMedicamento(
            Medicamento medicamento){

        service.agregar(medicamento);
    }
}
