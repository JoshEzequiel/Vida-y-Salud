package org.example.Repository;

import org.example.Conexion.Conexion;
import org.example.Model.Medicamento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicamentoRepository {

    public void guardar(Medicamento medicamento) {

        String sql =
                "INSERT INTO medicamento(nombre, descripcion, stock) VALUES (?, ?, ?)";

        try (
                Connection con = Conexion.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, medicamento.getNombre());
            ps.setString(2, medicamento.getDescripcion());
            ps.setInt(3, medicamento.getStock());

            ps.executeUpdate();

            System.out.println("Medicamento guardado en MySQL");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Medicamento> listar() {

        List<Medicamento> medicamentos = new ArrayList<>();

        String sql = "SELECT * FROM medicamento";

        try (
                Connection con = Conexion.conectar();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Medicamento medicamento = new Medicamento(
                        rs.getInt("id_medicamento"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("stock")
                );

                medicamentos.add(medicamento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return medicamentos;
    }
}
