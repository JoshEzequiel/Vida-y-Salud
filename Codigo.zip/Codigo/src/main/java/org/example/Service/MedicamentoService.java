package org.example.Service;

import org.example.Model.Medicamento;
import org.example.Repository.MedicamentoRepository;

import java.util.List;

public class MedicamentoService {

    private MedicamentoRepository repository =
            new MedicamentoRepository();

    public void agregar(
            Medicamento medicamento){

        if(medicamento.getStock() < 0){

            System.out.println("Stock inválido");
            return;
        }

        repository.guardar(medicamento);
    }

    public List<Medicamento> listar(){

        return repository.listar();
    }
}