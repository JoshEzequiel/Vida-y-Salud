package org.example.Service;



import org.example.Model.Usuario;
import org.example.Repository.UsuarioRepository;

import java.util.List;

public class UsuarioService {

    private UsuarioRepository repository =
            new UsuarioRepository();

    public void agregarUsuario(
            Usuario usuario){

        repository.guardar(usuario);
    }

    public List<Usuario> listar(){

        return repository.listar();
    }

    public boolean login(
            String username,
            String password){

        for(Usuario u : repository.listar()){

            if(u.getUsername().equals(username)
                    &&
                    u.getPassword().equals(password)){

                return true;
            }
        }

        return false;
    }
}
